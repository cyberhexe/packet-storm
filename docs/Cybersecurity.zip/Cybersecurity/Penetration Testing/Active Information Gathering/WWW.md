# WWW
### WWW

1.1 Enumerating web services 1.1.1 Using wmap scanner msf > load wmap msf > wmap\_sites -a http://172.16.194.172 msf > wmap\_targets -t http://172.16.194.172/mutillidae/index.php msf > wmap\_run -t msf > wmap\_run -e

1.1.2 Using nikto nikto -C all --host https://x.com