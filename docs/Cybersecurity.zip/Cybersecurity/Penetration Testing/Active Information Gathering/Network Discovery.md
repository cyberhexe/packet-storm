# Network Discovery
### Network Discovery

1.1 Performing network discovery 1.1.1 Probing IPv6 neighbor solicitations msf > use auxiliary/scanner/discovery/ipv6\_neighbor msf auxiliary(ipv6\_neighbor) > set RHOSTS 192.168.1.2-254 msf auxiliary(ipv6\_neighbor) > set SHOST 192.168.1.101 msf auxiliary(ipv6\_neighbor) > set SMAC d6:46:a7:38:15:65 msf auxiliary(ipv6\_neighbor) > set THREADS 55 msf auxiliary(ipv6\_neighbor) > run

1.1.2 Probing common UDP services msf > use auxiliary/scanner/discovery/udp\_probe msf auxiliary(udp\_probe) > set RHOSTS 192.168.1.2-254 msf auxiliary(udp\_probe) > set THREADS 253 msf auxiliary(udp\_probe) > run

msf > use auxiliary/scanner/discovery/udp\_sweep msf auxiliary(udp\_sweep) > set RHOSTS 192.168.1.2-254 msf auxiliary(udp\_sweep) > set THREADS 253 msf auxiliary(udp\_sweep) > run